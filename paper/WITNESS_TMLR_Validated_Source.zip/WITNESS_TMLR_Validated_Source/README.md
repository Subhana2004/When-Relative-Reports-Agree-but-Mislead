# Anonymous TMLR-format manuscript source

Compile from this directory with two runs of `pdflatex -interaction=nonstopmode main.tex`.
The authorship fields are deliberately blank for double-blind review. This is an updated
research draft, not confirmation of final scientific readiness or a journal submission.
Do not add personal metadata to the reviewer PDF or supplementary ZIP.
